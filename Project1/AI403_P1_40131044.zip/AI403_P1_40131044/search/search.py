# search.py
# ---------
# Licensing Information:  You are free to use or extend these projects for
# educational purposes provided that (1) you do not distribute or publish
# solutions, (2) you retain this notice, and (3) you provide clear
# attribution to UC Berkeley, including a link to http://ai.berkeley.edu.
# 
# Attribution Information: The Pacman AI projects were developed at UC Berkeley.
# The core projects and autograders were primarily created by John DeNero
# (denero@cs.berkeley.edu) and Dan Klein (klein@cs.berkeley.edu).
# Student side autograding was added by Brad Miller, Nick Hay, and
# Pieter Abbeel (pabbeel@cs.berkeley.edu).


"""
In search.py, you will implement generic search algorithms which are called by
Pacman agents (in searchAgents.py).
"""

import util
from game import Directions
from typing import List

class SearchProblem:
    """
    This class outlines the structure of a search problem, but doesn't implement
    any of the methods (in object-oriented terminology: an abstract class).

    You do not need to change anything in this class, ever.
    """

    def getStartState(self):
        """
        Returns the start state for the search problem.
        """
        util.raiseNotDefined()

    def isGoalState(self, state):
        """
          state: Search state

        Returns True if and only if the state is a valid goal state.
        """
        util.raiseNotDefined()

    def getSuccessors(self, state):
        """
          state: Search state

        For a given state, this should return a list of triples, (successor,
        action, stepCost), where 'successor' is a successor to the current
        state, 'action' is the action required to get there, and 'stepCost' is
        the incremental cost of expanding to that successor.
        """
        util.raiseNotDefined()

    def getCostOfActions(self, actions):
        """
         actions: A list of actions to take

        This method returns the total cost of a particular sequence of actions.
        The sequence must be composed of legal moves.
        """
        util.raiseNotDefined()




def tinyMazeSearch(problem: SearchProblem) :
    """
    Returns a sequence of moves that solves tinyMaze.  For any other maze, the
    sequence of moves will be incorrect, so only use this for tinyMaze.
    """
    from game import Directions
    s = Directions.SOUTH
    w = Directions.WEST
    return  [s, s, w, s, w, w, s, w]

def depthFirstSearch(problem: SearchProblem) :
    """
    Search the deepest nodes in the search tree first.

    Your search algorithm needs to return a list of actions that reaches the
    goal. Make sure to implement a graph search algorithm.

    To get started, you might want to try some of these simple commands to
    understand the search problem that is being passed in:

    print("Start:", problem.getStartState())
    print("Is the start a goal?", problem.isGoalState(problem.getStartState()))
    print("Start's successors:", problem.getSuccessors(problem.getStartState()))
    """
    "*** YOUR CODE HERE ***"
    # Initialize the stack for DFS and set the initial state and path
    stack = util.Stack()
    initial_state = problem.getStartState()  # Get the starting state from the problem
    path_so_far = []  # List to store the path taken so far
    stack.push((initial_state, path_so_far))  # Push the initial state and empty path onto the stack

    # Set to keep track of visited states
    explored = set()

    # Main DFS loop
    while not stack.isEmpty():
        state, path = stack.pop()  # Pop the next state and its associated path from the stack
        
        # Check if the current state is the goal state
        if problem.isGoalState(state):
            return path  # If goal is reached, return the path to the goal
        
        # Add the current state to the set of explored states
        explored.add(state)
        
        # Get the successors (neighbors) of the current state
        neighbors = problem.getSuccessors(state)
        
        # Explore each neighbor
        for neighbor in neighbors:
            # If the neighbor has not been visited yet
            if neighbor[0] not in explored:
                # Push the neighbor and the updated path onto the stack
                stack.push((neighbor[0], path + [neighbor[1]]))

    # If no path is found, return an empty list
    return []

   
def breadthFirstSearch(problem: SearchProblem) :
    """Search the shallowest nodes in the search tree first."""
    "*** YOUR CODE HERE ***"
    # Initialize the queue for BFS and set the initial state and path
    queue = util.Queue()
    start_state = problem.getStartState()  # Get the starting state from the problem
    path_so_far = []  # List to store the path taken so far
    queue.push((start_state, path_so_far))  # Push the start state and empty path onto the queue

    # Set to keep track of explored states
    explored = set()

    # Main BFS loop
    while not queue.isEmpty():
        state, path = queue.pop()  # Dequeue the next state and its associated path
        
        # Check if the current state is the goal state
        if problem.isGoalState(state):
            return path  # If goal is reached, return the path to the goal
        
        # Add the current state to the set of explored states
        explored.add(state)
        
        # Get the successors (neighbors) of the current state
        neighbors = problem.getSuccessors(state)
        
        # Explore each neighbor
        for neighbor, action, cost in neighbors:
            # If the neighbor has not been explored yet
            if neighbor not in explored:
                # Check if the neighbor is not already in the queue
                if neighbor not in (item[0] for item in queue.list):
                    # Push the neighbor and the updated path onto the queue
                    queue.push((neighbor, path + [action]))

    # If no path is found, return an empty list
    return []

    # util.raiseNotDefined()

def uniformCostSearch(problem: SearchProblem) :
    """Search the node of least total cost first."""
    "*** YOUR CODE HERE ***"
    # Initialize the priority queue for A* (or uniform-cost) search
    priority_queue = util.PriorityQueue()
    start_state = problem.getStartState()  # Get the starting state from the problem
    path_so_far = []  # List to store the path taken so far
    priority_queue.push((start_state, path_so_far), 0)  # Push the start state and empty path onto the priority queue

    # Set to keep track of visited states
    explored = set()

    # Main loop for the priority queue-based search
    while not priority_queue.isEmpty():
        state, path = priority_queue.pop()  # Pop the state with the lowest cost and its associated path
        
        # Skip if the state has already been explored
        if state in explored:
            continue
        
        # Check if the current state is the goal state
        if problem.isGoalState(state):
            return path  # If goal is reached, return the path to the goal
        
        # Add the current state to the set of explored states
        explored.add(state)
        
        # Get the successors (neighbors) of the current state
        neighbors = problem.getSuccessors(state)
        
        # Explore each neighbor
        for neighbor, action, cost in neighbors:
            # Update the path by appending the action taken
            new_path = path + [action]
            
            # Calculate the cost of the new path
            total_cost = problem.getCostOfActions(new_path)
            
            # If the neighbor hasn't been explored yet, push it to the queue with the associated cost
            if neighbor not in explored:
                priority_queue.push((neighbor, new_path), total_cost)

    # If no path is found, return an empty list
    return []


    

def nullHeuristic(state, problem=None) -> float:
    """
    A heuristic function estimates the cost from the current state to the nearest
    goal in the provided SearchProblem.  This heuristic is trivial.
    """
    return 0
    


def aStarSearch(problem: SearchProblem, heuristic=nullHeuristic) :
    """Search the node that has the lowest combined cost and heuristic first."""
    "*** YOUR CODE HERE ***"
    # Initialize the priority queue for A* (or UCS) search
    pq = util.PriorityQueue()
    start_state = problem.getStartState()  # Get the starting state from the problem
    path_so_far = []  # List to store the path taken so far
    pq.push((start_state, path_so_far), 0)  # Push the start state and empty path onto the priority queue

    # Dictionary to keep track of visited states and their associated cost
    visited_states = {}

    # Main loop for the priority queue-based search
    while not pq.isEmpty():
        current_state, current_path = pq.pop()  # Pop the state with the lowest cost and its associated path
        
        # If the state has already been visited with a lower or equal cost, skip it
        if current_state in visited_states and visited_states[current_state] <= problem.getCostOfActions(current_path):
            continue
        
        # Check if the current state is the goal state
        if problem.isGoalState(current_state):
            return current_path  # If goal is reached, return the path to the goal
        
        # Mark the current state as visited with its associated cost
        visited_states[current_state] = problem.getCostOfActions(current_path)
        
        # Get the successors (neighbors) of the current state
        successors = problem.getSuccessors(current_state)
        
        # Explore each successor (neighbor)
        for neighbor, action, cost in successors:
            # Update the path by appending the action taken
            updated_path = current_path + [action]
            
            # Calculate the total cost (path cost + heuristic)
            total_cost = problem.getCostOfActions(updated_path) + heuristic(neighbor, problem)
            
            # Push the neighbor and the updated path to the priority queue
            pq.push((neighbor, updated_path), total_cost)

    # If no path is found, return an empty list
    return []

# Abbreviations
bfs = breadthFirstSearch
dfs = depthFirstSearch
astar = aStarSearch
ucs = uniformCostSearch
